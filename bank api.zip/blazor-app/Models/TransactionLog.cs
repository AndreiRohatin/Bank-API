﻿namespace BlazorApp.Models
{
    public class TransactionLog
    {
        public int Id { get; set; }
        //id reference for accounts
        public int SenderId { get; set; }
        public int RecieverId { get; set; }
        public string Currency { get; set; }
        public double Value { get; set; }
        public string Date { get; set; }
    }
}