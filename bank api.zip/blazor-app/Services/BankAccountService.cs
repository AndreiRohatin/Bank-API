﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BlazorApp.Models;
using Microsoft.AspNetCore.Components;

namespace BlazorApp.Services
{    public interface IBankAccountService
    {
        BankAccount BankAccount { get; }
        
        Task<BankAccount> GetById(string id);
        Task<BankAccount> GetByIban(string iban);
        //out of time for the rest of the implementation
        //Task Register(BankAccount model);
        //Task Update(int id, BankAccount model);
        //Task Delete(int id);

        //Task SendMoneyIban(int senderId, int receiverId, double value,string pin);

        //Task Withdraw(int id, double value, string pin);
        //Task Deposit(int id, double value, string pin);


    }
    public class BankAccountService : IBankAccountService
    {
        private IHttpService _httpService;
        private NavigationManager _navigationManager;
        private ILocalStorageService _localStorageService;
        private string _bankAccountKey = "bankAccount";
        
        public BankAccount BankAccount { get; private set; }
        
        public BankAccountService(
            IHttpService httpService,
            NavigationManager navigationManager,
            ILocalStorageService localStorageService
        ) {
            _httpService = httpService;
            _navigationManager = navigationManager;
            _localStorageService = localStorageService;
        }

        public async Task Initialize()
        {
            BankAccount = await _localStorageService.GetItem<BankAccount>(_bankAccountKey);
        }

        public async Task<BankAccount> GetById(string id)
        {
            return await _httpService.Get<BankAccount>($"bankaccount/{id}");
        }

        public async Task<BankAccount> GetByIban(string id)
        {
            return await _httpService.Get<BankAccount>($"bankaccount/iban/{id}");
        }
    }
}
