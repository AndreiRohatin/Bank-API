﻿namespace WebApi.Models.TransactionLog
{
    public class TransactionLogModel
    {
        
        public string Id { get; set; }
        //id reference for accounts
        public int SenderId { get; set; }
        public int RecieverId { get; set; }
        public string Currency { get; set; }
        public double Value { get; set; }
        public string Date { get; set; }
    }
}