﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.TransactionLog
{
    public class RegisterRequest
    {
        [Required]
        public int SenderId { get; set; }
        [Required]
        public int RecieverId{get; set; }
        [Required]
        public string Currency { get; set; }
        [Required]
        public double Value { get; set; }
        [Required]
        public double Date { get; set; }
    }
}