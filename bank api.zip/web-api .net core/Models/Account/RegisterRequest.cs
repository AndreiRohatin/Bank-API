﻿using System.ComponentModel.DataAnnotations;

namespace WebApi.Models.Account
{
    public class RegisterRequest
    {
        [Required]
        public int UserId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Currency { get; set; }
        [Required]
        public string Pin { get; set; }
        [Required]
        public double Value { get; set; }
        [Required]
        public string Type { get; set; }
        public string Iban { get; set; }
    }
}