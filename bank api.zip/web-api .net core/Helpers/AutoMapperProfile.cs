using AutoMapper;
using WebApi.Entities;
using WebApi.Models.Users;

namespace WebApi.Helpers
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<User, UserModel>();
            CreateMap<RegisterModel, User>();
            CreateMap<UpdateModel, User>();
            CreateMap<WebApi.Models.Account.RegisterRequest, Account>();
            CreateMap<WebApi.Models.Account.UpdateRequest, Account>();
            //CreateMap<Account,AccountModel>();
            CreateMap<WebApi.Models.TransactionLog.RegisterRequest, TransactionLog>();
            //CreateMap<TransactionLog, TransactionLogModel>();
        }
    }
}