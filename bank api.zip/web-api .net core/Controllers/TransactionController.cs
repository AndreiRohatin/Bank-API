﻿using System.Collections.Generic;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using WebApi.Helpers;
using WebApi.Models.TransactionLog;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class TransactionController : ControllerBase
    {
        private ITransactionLogService _transactionLogService;
        private IMapper _mapper;
        private readonly AppSettings _appSettings;
        
        public TransactionController(ITransactionLogService transactionLogService, IMapper mapper,IOptions<AppSettings> appSettings)
        {
            _transactionLogService = transactionLogService;
            _mapper = mapper;
            _appSettings = appSettings.Value;
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var transactions = _transactionLogService.GetAll();
            var model = _mapper.Map<IList<TransactionLogModel>>(transactions);
            return Ok(model);
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var transaction = _transactionLogService.GetById(id);
            var model = _mapper.Map<TransactionLogModel>(transaction);
            return Ok(model);
        }

        [HttpGet("{id},{startDate},{endDate}")]
        public IActionResult FilterByDateAndUser(int id, string startdate, string endDate)
        {
            var transaction = _transactionLogService.FilterByDateAndUser(id, startdate, endDate);
            var model = _mapper.Map<IList<TransactionLogModel>>(transaction);
            return Ok(model);
        }
    }
}