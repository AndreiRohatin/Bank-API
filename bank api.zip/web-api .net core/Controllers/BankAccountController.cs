﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using WebApi.Entities;
using WebApi.Helpers;
using WebApi.Models.Account;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Authorize]
    [ApiController]
    [Microsoft.AspNetCore.Components.Route("[controller]")]
    public class BankAccountController : ControllerBase
    {
        private IAccountService _accountService;
        private IMapper _mapper;
        private readonly AppSettings _appSettings;

        public BankAccountController(IAccountService accountService, IMapper mapper, IOptions<AppSettings> appSettings)
        {
            _mapper = mapper;
            _accountService = accountService;
            _appSettings = appSettings.Value;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] RegisterRequest model)
        {
            try
            {
                //create account
                _accountService.Register(model);
                return Ok();
            }
            catch(AppException ex)
            {
                return BadRequest(new {message = ex.Message});
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var account = _accountService.GetById(id);
            var model = _mapper.Map<AccountModel>(account);
            return Ok(model);
        }

        [Route("iban/{id}")]
        public IActionResult GetByIban(string iban)
        {
            var account = _accountService.GetByIban(iban);
            var model = _mapper.Map<AccountModel>(account);
            return Ok(model);
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] UpdateRequest model)
        {
            try
            {
                _accountService.Update(id, model);
                return Ok();
            }
            catch (AppException ex)
            {
                return BadRequest(new {message = ex.Message});
            }
        }

        [HttpPut("{id}")]
        public IActionResult Delete(int id)
        {
            _accountService.Delete(id);
            return Ok();
        }
    }
}