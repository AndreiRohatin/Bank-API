﻿namespace WebApi.Entities
{
    public class Account
    {
        public int Id { get; set; }
        //an account will be assigned to only one user
        public int UserId { get; set; }
        public string Name { get; set; }
        public string Iban { get; set; }
        public string Currency { get; set; }
        public string Pin { get; set; }
        public string Type { get; set; }
        public double Value { get; set; }
    }
}