﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using AutoMapper;
using WebApi.Entities;
using WebApi.Helpers;
using WebApi.Models.TransactionLog;

namespace WebApi.Services
{
    public interface ITransactionLogService
    {
        IEnumerable<TransactionLog> GetAll();
        IEnumerable<TransactionLog> GetAllByUserId(int id);
        IEnumerable<TransactionLog> FilterByDateAndUser(int id, string startDate, string endDate);
        TransactionLog GetById(int id);
        void Register(RegisterRequest model);
        void Delete(int id);

    }
    public class TransactionLogService : ITransactionLogService
    {
        private DataContext _context;
        private IMapper _mapper;

        public TransactionLogService(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public IEnumerable<TransactionLog> GetAll()
        {
            return _context.TransactionLogs;
        }

        public IEnumerable<TransactionLog> GetAllByUserId(int id)
        {
            return getTransactions(id);
        }

        public IEnumerable<TransactionLog> FilterByDateAndUser(int id, string startDate, string endDate)
        {
            return getTransactions(id,startDate,endDate);
        }

        public TransactionLog GetById(int id)
        {
            var transaction = _context.TransactionLogs.Find(id);
            if (transaction == null) throw new KeyNotFoundException("Transaction not found");
            return transaction;
        }

        public void Register(RegisterRequest model)
        {
            var transactionLog = _mapper.Map<TransactionLog>(model);

            _context.TransactionLogs.Add(transactionLog);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var transaction = _context.TransactionLogs.Find(id);
            if (transaction == null) throw new KeyNotFoundException("Transaction not found");
            _context.TransactionLogs.Remove(transaction);
            _context.SaveChanges();
        }
        
        #region HelperMethods

        private IEnumerable<TransactionLog> getTransactions(int id)
        {
            IEnumerable<TransactionLog> transactionLogs = _context.TransactionLogs.Where(o=>o.SenderId==id||o.RecieverId==id);
            if(transactionLogs==null) throw new KeyNotFoundException("Transactions not found");
            return transactionLogs;
        }

        private IEnumerable<TransactionLog> getTransactions(int id, string startDate, string endDate)
        {
            IEnumerable<TransactionLog> transactionLogs = _context.TransactionLogs.Where(o=>(o.SenderId==id||o.RecieverId==id)&&validate(o,startDate,endDate));
            if(transactionLogs==null) throw new KeyNotFoundException("Transactions not found");
            return transactionLogs;
            
        }

        private bool validate(TransactionLog transactionLog, string startDate, string endDate)
        {
            //could've write all the code in the lambda function but it didn't look pretty
            try
            {
                //check for switch dates by mistake
                if (DateTime.Parse(endDate, CultureInfo.InvariantCulture) <=
                    DateTime.Parse(startDate, CultureInfo.InvariantCulture))
                {
                    return false;
                }
                //define interval margins
                bool lowerMargin = DateTime.Parse(transactionLog.Date, CultureInfo.InvariantCulture) >=
                                   DateTime.Parse(startDate, CultureInfo.InvariantCulture);
                bool upperMargin = DateTime.Parse(transactionLog.Date, CultureInfo.InvariantCulture) <=
                                   DateTime.Parse(endDate, CultureInfo.InvariantCulture);
                return lowerMargin && upperMargin;
            }
            catch
            {
                return false;
            }
        }
        #endregion
    }
}