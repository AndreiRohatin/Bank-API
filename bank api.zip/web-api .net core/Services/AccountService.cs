﻿using System;
using System.Collections.Generic;
using AutoMapper;
using WebApi.Entities;
using WebApi.Helpers;
using WebApi.Models.Account;

namespace WebApi.Services
{
    public interface IAccountService
    {
        IEnumerable<Account> GetAll();
        Account GetById(int id);
        Account GetByIban(string iban);
        void Register(RegisterRequest model);
        void Update(int id, UpdateRequest model);
        void Delete(int id);

        void SendMoneyIban(int senderId, int receiverId, double value,string pin);

        void Withdraw(int id, double value, string pin);
        void Deposit(int id, double value, string pin);


    }
    public class AccountService : IAccountService
    {
        private DataContext _context;
        private readonly IMapper _mapper;

        public AccountService(DataContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public IEnumerable<Account> GetAll()
        {
            return _context.Accounts;
        }

        public Account GetById(int id)
        {
            return getAccount(id);
        }

        public Account GetByIban(string iban)
        {
            return getAccount(iban);
        }

        public void Register(RegisterRequest model)
        {
            var account = _mapper.Map<Account>(model);
            Guid ibanBuilder = Guid.NewGuid();
            account.Iban = Convert.ToBase64String(ibanBuilder.ToByteArray());
            account.Iban = account.Iban.Replace("+", "");
            account.Iban = account.Iban.Replace("=", "");
            _context.Accounts.Add(account);
            _context.SaveChanges();
        }

        public void Update(int id, UpdateRequest model)
        {
            var account = getAccount(id);
            
            //check if user wants to change currency without updating the value from the account
            if (model.Currency != account.Currency && model.Value == account.Value)
            {
                /////TODO change this bs
                model.Value = 0.1 * account.Value;
            }

            _mapper.Map(model,account);
            _context.Accounts.Update(account);
            _context.SaveChanges();
        }

        public void Delete(int id)
        {
            var account = getAccount(id);
            _context.Accounts.Remove(account);
            _context.SaveChanges();
        }

        public void SendMoneyIban(int senderId, int receiverId, double value,string pin)
        {
            Account sender = getAccount(senderId);
            Account receiver = getAccount(receiverId);
            if(sender.Pin!=pin)  throw new KeyNotFoundException("Wrong pin");
            if (sender.Currency == receiver.Currency)
            {
                //same currency so everythings is ok
                if (sender.Value < value) throw new KeyNotFoundException("Low balance");
                sender.Value -= value;
                receiver.Value += value;
                _context.Accounts.Update(sender);
                _context.Accounts.Update(receiver);
                _context.SaveChanges();
            }
            else
            {
                if(Program.ExchangeRates.ContainsKey($"{sender.Currency.ToUpper()}to{receiver.Currency.ToUpper()}"))
                {
                    if (sender.Value < value) throw new KeyNotFoundException("Low balance");
                    sender.Value -= value;
                    receiver.Value += value*Program.ExchangeRates[$"{sender.Currency.ToUpper()}to{receiver.Currency.ToUpper()}"];
                    _context.Accounts.Update(sender);
                    _context.Accounts.Update(receiver);
                    _context.SaveChanges();
                }else throw new KeyNotFoundException("No exchange rate");
            }
            
            //if we got here we made the transaction so we need to update the transactions log
            TransactionLog transactionLog=new TransactionLog();
            transactionLog.Currency = sender.Currency == receiver.Currency
                ? sender.Currency
                : $"{sender.Currency}to{receiver.Currency}";
            transactionLog.Date = DateTime.Now.ToString();
            transactionLog.RecieverId = receiverId;
            transactionLog.SenderId = senderId;
            transactionLog.Value = value;
            _context.Accounts.Update(sender);
            _context.Accounts.Update(receiver);
            _context.TransactionLogs.Update(transactionLog);
            _context.SaveChanges();
        }

        public void Withdraw(int id, double value,string pin)
        {
            Account account = getAccount(id);
            if(account.Pin!=pin)  throw new KeyNotFoundException("Wrong pin");
            if(account.Value<value) throw new KeyNotFoundException("Low balance");
            double commission=calculateCommissionAmount(value, account.Type, false);
            //admin has 2 accounts to recieve the commision: id=1 for RON and id=2 for EURO
            int type = account.Currency == "RON" ? 1 : 2;
            Account admin = getAccount(type);
            admin.Value += commission;
            account.Value -= value;
            account.Value -= commission;
            _context.Accounts.Update(account);
            _context.Accounts.Update(admin);
            _context.SaveChanges();
        }

        public void Deposit(int id, double value,string pin)
        {
            Account account = getAccount(id);
            if(account.Pin!=pin)  throw new KeyNotFoundException("Wrong pin");
            if(account.Value<value) throw new KeyNotFoundException("Low balance");
            double commission=calculateCommissionAmount(value, account.Type, false);
            //admin has 2 accounts to recieve the commision: id=1 for RON and id=2 for EURO
            int type = account.Currency == "RON" ? 1 : 2;
            Account admin = getAccount(type);
            admin.Value += commission;
            account.Value += value;
            account.Value -= commission;
            _context.Accounts.Update(account);
            _context.Accounts.Update(admin);
            _context.SaveChanges();
        }

        
        #region HelperMethods
        
        private Account getAccount(int id)
        {
            var account = _context.Accounts.Find(id);
            if (account == null) throw new KeyNotFoundException("Account not found");
            return account;
        }

        private Account getAccount(string iban)
        {
            var account = _context.Accounts.Find(iban);
            if (account == null) throw new KeyNotFoundException("Account not found");
            return account;
        }

        private double calculateCommissionAmount(double value, string accountType, bool isDeposit)
        {
            //treat deposit commission amount first since only Basic account have it
            if (isDeposit) return accountType != "Basic" ? 0 : value * 0.01;

            double retObj = 0;
            //we still need this part hardcoded to set commision amount for each type of account
            switch (accountType)
            {
                case "Gold":
                {
                    retObj = 0;
                    break;
                }
                case "Silver":
                {
                    retObj = value * 0.01;
                    break;
                }
                case "Basic":
                {
                    retObj = value * 0.015 + 2;
                    break;
                }
                default:
                {
                    break;
                }
            }
            return retObj;
        }
        #endregion
    }
}